import streamlit as st
import pandas as pd
from textblob import TextBlob
import matplotlib.pyplot as plt
import spacy
from collections import Counter
import re
import networkx as nx
from pyvis.network import Network
import streamlit.components.v1 as components
import base64

# --------------------- Background Styling ---------------------
def add_bg_from_local(image_file):
    with open(image_file, "rb") as f:
        encoded_string = base64.b64encode(f.read()).decode()
    st.markdown(
         f"""
         <style>
         .stApp {{
             background-image: url("data:image/jpeg;base64,{encoded_string}");
             background-size: cover;
             background-attachment: fixed;
             background-position: center;
             color: #39FF14; /* Neon green */
         }}
         </style>
         """,
         unsafe_allow_html=True
     )

add_bg_from_local("netra_bg.jpg")  # Make sure your image is saved as 'netra_bg.png' in the same folder

# --------------------- App Config ---------------------
st.set_page_config(page_title="NetraAI", layout="wide")
st.title("🕵️ NetraAI – OSINT Mood Profiler for India")
st.markdown("**Enter a public name or handle to generate a digital profile.**")

# --------------------- Input ---------------------
query = st.text_input("🔍 Search a Name or Twitter Handle", placeholder="e.g. @xyz or Rohit Sharma")

# --------------------- Sample Data ---------------------
sample_tweets = [
    "Feeling hopeful about the future. New opportunities coming!",
    "This government has failed again. Tired of corruption.",
    "Enjoying my weekend with friends. So much laughter and love.",
    "The economy is crashing. We're all doomed.",
    "Excited to share that I joined a new company today!",
    "The Prime Minister announced a new development scheme for rural areas.",
    "Apple is planning to open new offices in India by next year.",
    "Delhi pollution levels are rising again as winter sets in."
]

# Load spaCy model
nlp = spacy.load("en_core_web_sm")

# --------------------- Process ---------------------
if query:
    st.markdown("### 📄 Public Profile Summary")
    st.write(f"**Name/Handle:** `{query}` _(Sample data used)_")
    st.info("🧠 This profile is generated using public, open-source content. For demo purposes only.")

    st.markdown("### 📊 Mood & Sentiment Trend")
    sentiments = [TextBlob(t).sentiment.polarity for t in sample_tweets]
    df = pd.DataFrame({"Tweet": sample_tweets, "Sentiment Score": sentiments})
    st.dataframe(df)
    st.line_chart(df["Sentiment Score"])

    score = round(sum(sentiments) / len(sentiments), 2)
    st.markdown("### ⚠️ Risk / Trust Score")
    if score > 0.3:
        st.success(f"Low Risk – Trust Score: {score}")
    elif score < -0.3:
        st.error(f"High Risk – Trust Score: {score}")
    else:
        st.warning(f"Neutral / Monitor – Trust Score: {score}")

    st.markdown("### 🕸️ Entity Highlights")
    all_text = " ".join(sample_tweets)
    doc = nlp(all_text)
    entities = [(ent.text, ent.label_) for ent in doc.ents]
    if entities:
        df_ents = pd.DataFrame(entities, columns=["Entity", "Label"])
        st.dataframe(df_ents.drop_duplicates())
    else:
        st.write("No named entities detected.")

    st.markdown("### ☁️ Keyword Cloud (Top Mentions)")
    cleaned = re.sub(r'[^\w\s]', '', all_text.lower())
    words = [word for word in cleaned.split() if word not in nlp.Defaults.stop_words]
    top_keywords = Counter(words).most_common(10)
    for word, freq in top_keywords:
        st.write(f"- {word} ({freq} times)")

    st.markdown("### 🔗 Relationship Graph (Sample Co-Mentions)")
    G = nx.Graph()
    entities_only = [ent[0] for ent in entities if ent[1] in ["PERSON", "ORG"]]
    if not entities_only:
        entities_only = ["User", "India", "Govt", "Company"]

    for ent in entities_only:
        G.add_node(ent)
    for i in range(len(entities_only) - 1):
        G.add_edge(entities_only[i], entities_only[i + 1])

    net = Network(height="400px", width="100%", bgcolor="#222222", font_color="white")
    net.from_nx(G)
    net.save_graph("graph.html")
    HtmlFile = open("graph.html", "r", encoding="utf-8")
    components.html(HtmlFile.read(), height=400)

    st.markdown("### 📄 Download Report Summary")
    report = f"""
NetraAI Report for: {query}
--------------------------
Risk Score: {score}
Top Entities: {[e[0] for e in entities[:5]]}
Top Keywords: {[kw[0] for kw in top_keywords[:5]]}
"""
    st.download_button("Download Report", report, file_name="NetraAI_Report.txt")

    st.markdown("---")
    st.caption("Built with 💡 by Team NetraAI | Demo prototype | Data used here is public & synthetic.")
